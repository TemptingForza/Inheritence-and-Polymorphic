﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poly_And_Inherit
{
    abstract class Animal
    {
        public int id;
        public Animal(int id) { this.id = id; }
        public Animal() { }
        public abstract double getProf();
    }
}