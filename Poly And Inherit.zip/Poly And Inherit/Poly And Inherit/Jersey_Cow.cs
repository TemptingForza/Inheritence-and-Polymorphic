﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poly_And_Inherit
{
    class Jersey_Cow: Cow
    {
        public Jersey_Cow(int  id, double amtMilk) : base(id, amtMilk) { }
        public override double getProf()
        {
            double profit = 0.0;
            profit += amtMilk * Price.cowMilkPrice * 365;
            profit -= Price.jCVaccination;
            return profit;
        }
    }
}
