﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poly_And_Inherit
{
    class Cow: Animal
    {
        public double amtMilk;

        public Cow(int id, double amtMilk): base(id) { this.amtMilk = amtMilk; }
        public override double getProf()
        {
            double profit = 0.0;
            profit += amtMilk * Price.cowMilkPrice * 365;
            profit -= Price.cowVaccination;
            return profit;
        }
    }
}
