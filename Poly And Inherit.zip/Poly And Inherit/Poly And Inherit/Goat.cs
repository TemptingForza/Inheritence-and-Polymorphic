﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poly_And_Inherit
{
    class Goat: Animal
    {
        public double amtMilk;
        public Goat(int id, double amtMilk) : base(id) { this.amtMilk = amtMilk; }
        public override double getProf()
        {
            double profit = 0.0;
            profit += amtMilk * Price.goatMilkPrice * 365;
            profit -= Price.goatVaccination;
            return profit;
        }
    }
}
