﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poly_And_Inherit
{
    public class Price
    {
        public static double cowMilkPrice;
        public static double goatMilkPrice;
        public static double cowVaccination;
        public static double jCVaccination;
        public static double goatVaccination;

        public static double calculateCowProfit(double milky)
        {
            return (milky * cowMilkPrice * 365) - cowVaccination;
        }
        public static double calculateJCProfit(double milky)
        {
            return (milky * cowMilkPrice * 365) - jCVaccination;
        }
        public static double calculateGoatProfit(double milky)
        {
            return (milky * goatMilkPrice * 365) - goatVaccination;

        }

    }
}

