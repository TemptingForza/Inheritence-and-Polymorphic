﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Poly_And_Inherit
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private double totProf(Animal[] A)
        {
            double tot = 0.0;
            for (int i = 0; i < 10; i++)
            {
                tot = tot + A[i].getProf();
            }
            return (tot);
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            // Creating a dictionary
            // using Dictionary<TKey,TValue> class
            Dictionary<int, string> My_dict =
                          new Dictionary<int, string>();

            // Adding key/value pairs in the 
            // Dictionary Using Add() method
            My_dict.Add(1000, "Jersey_Cow");
            My_dict.Add(1033, "Jersey_Cow");
            My_dict.Add(1021, "Jersey_Cow");
            My_dict.Add(1100, "Cow");
            My_dict.Add(1131, "Cow");
            My_dict.Add(1099, "Cow");
            My_dict.Add(1101, "Cow");
            My_dict.Add(2110, "Goat");
            My_dict.Add(2145, "Goat");
            My_dict.Add(2129, "Goat"); // 50

            //foreach (KeyValuePair<int, string> ele1 in My_dict)
                //Console.WriteLine("Key: {0}, Value: {1}", ele1.Key, ele1.Value);
            //var Animals = new Dictionary<int, string, string>() {
                //{"1000,10,Jersey_Cow"},
                //{"1100,30,Cow"},
                //{"2110,20,Goat"},
                //{"2145,15,Goat"},
                //{"2129,17,Goat"},
                //{"1131,12,Cow"},
                //{"1099,22,Cow"},
                //{"1033,44,Jersey_Cow"},
                //{"1021,22,Jersey_Cow"},
                //{"1101,10,Cow"},
            //};

            //foreach (var kvp in Animals)
                //Console.WriteLine("Key: {0}, Value: {1}", kvp.Key, kvp.Value);

            //try catches any error when start 
            try
            {
                //bool is incase something does break to convert to true if successful if not true does nothing
                bool cont = false;

                if (String.IsNullOrWhiteSpace(textBox1.Text) || String.IsNullOrWhiteSpace(textBox7.Text) || String.IsNullOrWhiteSpace(textBox8.Text) ||
                    String.IsNullOrWhiteSpace(textBox9.Text) || String.IsNullOrWhiteSpace(textBox10.Text))
                {
                    MessageBox.Show("Please enter a price");
                }
                else
                {
                    try
                    {
                        Price.cowMilkPrice = double.Parse(textBox1.Text);
                        Price.goatMilkPrice = double.Parse(textBox7.Text);
                        Price.cowVaccination = double.Parse(textBox8.Text);
                        Price.jCVaccination = double.Parse(textBox9.Text);
                        Price.goatVaccination = double.Parse(textBox10.Text);
                        cont = true;
                    }
                    catch
                    {
                        MessageBox.Show("Please enter a valid price");
                    }

                    //if statement makes sure textbox has some text in it
                    if (cont == true)
                    {
                        //C:\\Users\\Manrat\\source\\repos\\Poly And Inherit\\Mcdonald.txt
                        //textBox11.Text
                        string[] content = System.IO.File.ReadAllLines("C:\\Users\\Manrat\\source\\repos\\Poly And Inherit\\Mcdonald.txt");
                        Animal[] listed = new Animal[content.Length];
                        int count = 0;

                        double cowProfits = 0.0;
                        double jcProfits = 0.0;
                        double goatProfits = 0.0;

                        foreach (String line in content)
                        {
                            string[] trimmed = line.Trim().Split(',');
                            int ID = int.Parse(trimmed[0].Trim());
                            double mAmount = double.Parse(trimmed[1].Trim());
                            string type = trimmed[2].Trim();

                            if (type == "Cow")
                            {
                                listed[count] = new Cow(ID, mAmount);
                                cowProfits += Price.calculateCowProfit(mAmount);
                                count++;
                                break;
                            }
                            else if (type == "Jersey_Cow")
                            {
                                listed[count] = new Jersey_Cow(ID, mAmount);
                                jcProfits += Price.calculateJCProfit(mAmount);
                                count++;
                                break;
                            }
                            else
                            {
                                listed[count] = new Goat(ID, mAmount);
                                goatProfits += Price.calculateGoatProfit(mAmount);
                                count++;
                                break;

                            }
                        }

                        FilesName.Text=((goatProfits + cowProfits + jcProfits).ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void FilesName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
    
        }
    }
}
